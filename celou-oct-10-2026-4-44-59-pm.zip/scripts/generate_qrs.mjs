import { createCanvas, loadImage } from 'canvas';
import QRCode from 'qrcode';
import fs from 'fs';

function crc16(str) {
    let crc = 0xFFFF;
    for (let c = 0; c < str.length; c++) {
        crc ^= str.charCodeAt(c) << 8;
        for (let i = 0; i < 8; i++) {
            if (crc & 0x8000) crc = (crc << 1) ^ 0x1021;
            else crc = crc << 1;
            crc &= 0xFFFF;
        }
    }
    return crc.toString(16).toUpperCase().padStart(4, '0');
}

function buildQRPhPayload(bankType, amount = null) {
    // EMVCo format
    let payload = '000201'; // Payload Format Indicator
    payload += amount ? '010212' : '010211'; // 11: Static, 12: Dynamic
    
    // Merchant Account Info
    if (bankType === 'GCASH') {
        const sub00 = '0010ph.ppmi.p2p';
        const sub01 = '010201'; // mobile
        const sub02 = '0213+639760465134';
        const sub03 = '0311GXCHPHM2XXX';
        const full26 = sub00 + sub01 + sub02 + sub03;
        payload += '26' + String(full26.length).padStart(2, '0') + full26;
    } else {
        const sub00 = '0010ph.ppmi.p2p';
        const sub01 = '010202'; // bank acct
        const sub02 = '02106589452155';
        const sub03 = '0311BOPIPHMMXXX'; // BPI BIC
        const full26 = sub00 + sub01 + sub02 + sub03;
        payload += '26' + String(full26.length).padStart(2, '0') + full26;
    }
    
    payload += '52040000'; // Merchant Category
    payload += '5303608';  // Currency PHP
    if (amount && amount > 0) {
        const amtStr = Number(amount).toFixed(2);
        payload += '54' + String(amtStr.length).padStart(2, '0') + amtStr;
    }
    payload += '5802PH';   // Country
    const name = bankType === 'GCASH' ? 'TUHAMIE D' : 'CELOU TUHAMIE';
    payload += '59' + String(name.length).padStart(2, '0') + name;
    payload += '6006TAGUIG'; // City
    
    // Checksum tag
    const preCrc = payload + '6304';
    const checksum = crc16(preCrc);
    return preCrc + checksum;
}

function drawInstaPayBadge(ctx, centerX, centerY, size = 64) {
    const w = size * 1.3;
    const h = size * 0.75;
    ctx.save();
    ctx.fillStyle = '#ffffff';
    ctx.shadowColor = 'rgba(0,0,0,0.25)';
    ctx.shadowBlur = 6;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 2;
    ctx.beginPath();
    ctx.roundRect(centerX - w / 2, centerY - h / 2, w, h, 8);
    ctx.fill();
    ctx.shadowColor = 'transparent';
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    ctx.stroke();

    // Text: insta (navy) Pay (red)
    ctx.font = 'bold 15px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    
    // insta in deep navy blue
    ctx.fillStyle = '#0f2f64';
    ctx.fillText('insta', centerX, centerY - 6);
    
    // Pay in red with red wing
    ctx.fillStyle = '#e11d48';
    ctx.fillText('Pay', centerX, centerY + 9);

    // red stripes under insta
    ctx.fillStyle = '#e11d48';
    ctx.fillRect(centerX - 16, centerY - 1, 32, 2);

    ctx.restore();
}

async function generateBPIImage() {
    const width = 480;
    const height = 820;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);

    // Header BPI
    ctx.textAlign = 'center';
    ctx.fillStyle = '#d0001b';
    ctx.font = '900 42px sans-serif';
    ctx.fillText('BPI', width / 2, 70);

    // Celou
    ctx.fillStyle = '#1e293b';
    ctx.font = 'bold 26px sans-serif';
    ctx.fillText('Celou', width / 2, 120);

    // Masked name
    ctx.fillStyle = '#475569';
    ctx.font = '600 16px sans-serif';
    ctx.fillText('TU••••E AN••A DI••••G MA••A...', width / 2, 160);

    // Masked account number
    ctx.fillStyle = '#475569';
    ctx.font = 'bold 19px monospace';
    ctx.fillText('••••••••••155', width / 2, 200);

    // QR Code
    const qrPayload = buildQRPhPayload('BPI');
    const qrCanvas = createCanvas(330, 330);
    await QRCode.toCanvas(qrCanvas, qrPayload, {
        width: 330,
        margin: 1,
        errorCorrectionLevel: 'H',
        color: {
            dark: '#0f172a',
            light: '#ffffff'
        }
    });

    const qrX = (width - 330) / 2;
    const qrY = 250;
    ctx.drawImage(qrCanvas, qrX, qrY);

    // InstaPay logo in center
    drawInstaPayBadge(ctx, width / 2, qrY + 165, 54);

    // Footer
    ctx.fillStyle = '#64748b';
    ctx.font = '500 16px sans-serif';
    ctx.fillText('Transfer fees may apply', width / 2, 640);

    const bufferJpg = canvas.toBuffer('image/jpeg', { quality: 0.95 });
    fs.writeFileSync('BPI.jpg', bufferJpg);
    const bufferPng = canvas.toBuffer('image/png');
    fs.writeFileSync('BPI.png', bufferPng);
    console.log('Saved BPI.jpg and BPI.png successfully!');
}

async function generateGCashImage() {
    const width = 480;
    const height = 800;
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);

    // QR Code on top
    const qrPayload = buildQRPhPayload('GCASH');
    const qrCanvas = createCanvas(350, 350);
    await QRCode.toCanvas(qrCanvas, qrPayload, {
        width: 350,
        margin: 1,
        errorCorrectionLevel: 'H',
        color: {
            dark: '#0f172a',
            light: '#ffffff'
        }
    });

    const qrX = (width - 350) / 2;
    const qrY = 60;
    ctx.drawImage(qrCanvas, qrX, qrY);

    // InstaPay logo in center
    drawInstaPayBadge(ctx, width / 2, qrY + 175, 54);

    ctx.textAlign = 'center';
    ctx.fillStyle = '#64748b';
    ctx.font = '500 16px sans-serif';
    ctx.fillText('Transfer fees may apply.', width / 2, 455);

    // Name TU****E D. with pencil icon
    ctx.fillStyle = '#005ce6';
    ctx.font = 'bold 28px sans-serif';
    ctx.fillText('TU****E D.  ✎', width / 2, 515);

    // Mobile No.
    ctx.fillStyle = '#64748b';
    ctx.font = '600 17px sans-serif';
    ctx.fillText('Mobile No.: +63 976 046 ••••', width / 2, 560);

    // User ID
    ctx.fillText('User ID: ••••••••••8QM4GR', width / 2, 600);

    // Dashed line
    ctx.save();
    ctx.setLineDash([6, 6]);
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(30, 680);
    ctx.lineTo(width - 30, 680);
    ctx.stroke();
    ctx.restore();

    const bufferJpg = canvas.toBuffer('image/jpeg', { quality: 0.95 });
    fs.writeFileSync('Gcash.jpg', bufferJpg);
    const bufferPng = canvas.toBuffer('image/png');
    fs.writeFileSync('Gcash.png', bufferPng);
    console.log('Saved Gcash.jpg and Gcash.png successfully!');
}

async function main() {
    await generateBPIImage();
    await generateGCashImage();
}

main().catch(console.error);
